
Nama :
1. Sani Rahmawati  					(2014150126)
kelas 2
----------------------------------------------------------------
- Instal Laravel: `composer install --prefer-dist`
- Migrasikan database: `php artisan migrate`
- Ketikan Perintah: `php artisan db: seed`
- Lihat aplikasi di browser.
